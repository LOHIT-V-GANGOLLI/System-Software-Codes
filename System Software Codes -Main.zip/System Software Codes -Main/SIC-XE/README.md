## Pass 1 for SIC/XE
pass1.c program takes input.txt and optab.txt as input and generates intermediate.txt 
## Pass 2 for SIC/XE
⚠️ pass2.c will handle inputs of format 1 and format 2 only ⚠️\
pass 2 will take test.txt as input which has instructions of format 1 and format 2 only , that will generate object_program.txt as output
