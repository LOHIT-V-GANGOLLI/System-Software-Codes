# System-software-lab
This repository has pass 1 and pass 2 implementation of SIC , SIC/XE and Linking Loader \
Read README.md files in the respective folders for more details
