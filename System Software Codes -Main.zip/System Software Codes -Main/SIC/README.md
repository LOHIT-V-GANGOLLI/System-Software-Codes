# System-software-lab

This repository has the implementation of pass-1 and pass-2 algorithm of SIC Architecture

## pass_1.c

pass_1.c takes the input.txt and optab.txt as input and generates intermediate.txt , and symtab.txt as ouput files , i have included intermediate.txt and symtab.txt
just for reference these files are input for pass2

## pass_2.c

pass_2.c takes intermediate_temp.txt(this is a copy of intermediate.txt for easier parsing the spacing has been changed) , optab.txt , symtab.txt
and generates object_program.txt which
has object program

Do suggest changes if any Thanks.\
Mailme @ annikulkarni0802@gmail.com
